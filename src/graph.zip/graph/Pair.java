package graph;


public class Pair {

	Object ob1;
	Object ob2;
	
	public Pair(Object ob1, Object ob2){
		this.ob1 = ob1;
		this.ob2 = ob2;
	}

}
